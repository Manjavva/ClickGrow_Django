// Lightweight interactions: accessible mobile navigation, counters, carousel, and newsletter feedback.
lucide.createIcons();

const menuButton = document.querySelector('#menuButton');
const mobileMenu = document.querySelector('#mobileMenu');
menuButton?.addEventListener('click', () => {
  const open = mobileMenu.classList.toggle('hidden') === false;
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.textContent = open ? '×' : '☰';
});

document.querySelectorAll('#mobileMenu a').forEach(link => link.addEventListener('click', () => {
  mobileMenu.classList.add('hidden'); menuButton.setAttribute('aria-expanded', 'false'); menuButton.textContent = '☰';
}));

const animateCounters = () => document.querySelectorAll('[data-count]').forEach(element => {
  if (element.dataset.done) return;
  element.dataset.done = 'true';
  const target = Number(element.dataset.count), start = performance.now(), duration = 1300;
  const tick = now => {
    const progress = Math.min((now - start) / duration, 1);
    element.textContent = `${element.dataset.prefix || ''}${Math.floor(target * (1 - Math.pow(1 - progress, 3))).toLocaleString()}${element.dataset.suffix || ''}`;
    if (progress < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
});
const results = document.querySelector('#results');
new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) animateCounters(); }), { threshold: .25 }).observe(results);

const track = document.querySelector('#testimonialTrack'); let index = 0;
const moveTestimonials = direction => { index = (index + direction + 3) % 3; track.style.transform = `translateX(-${index * 100}%)`; };
document.querySelector('#prevTestimonial')?.addEventListener('click', () => moveTestimonials(-1));
document.querySelector('#nextTestimonial')?.addEventListener('click', () => moveTestimonials(1));

document.querySelector('#newsletterForm')?.addEventListener('submit', event => {
  event.preventDefault(); const email = document.querySelector('#email'); const message = document.querySelector('#formMessage');
  if (!email.checkValidity()) { email.reportValidity(); return; }
  message.textContent = 'You’re on the list — welcome to the growth notes.'; message.classList.remove('hidden'); event.target.reset();
});
