from django.db import models


class NewsletterSubscriber(models.Model):
    """Email addresses collected from the ClickGrown footer form."""
    email = models.EmailField(unique=True)
    subscribed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-subscribed_at"]

    def __str__(self):
        return self.email
