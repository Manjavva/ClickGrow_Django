import json

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.http import require_GET, require_POST

from .forms import LoginForm, RegistrationForm
from .models import NewsletterSubscriber


def _payload(request):
    try:
        return json.loads(request.body or "{}")
    except json.JSONDecodeError:
        return None


@login_required
@require_GET
def home(request):
    return render(request, "accounts/home.html")


def register(request):
    if request.user.is_authenticated:
        return redirect("home")
    form = RegistrationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Your account is ready. Please sign in to continue.")
        return redirect("login")
    return render(request, "accounts/register.html", {"form": form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect("home")
    form = LoginForm(request, data=request.POST or None)
    if request.method == "POST" and form.is_valid():
        login(request, form.get_user())
        return redirect(request.POST.get("next") or "home")
    return render(request, "accounts/login.html", {"form": form})


@require_POST
def logout_view(request):
    logout(request)
    messages.info(request, "You have been signed out.")
    return redirect("login")


@require_POST
def subscribe(request):
    email = request.POST.get("email", "").strip().lower()
    if not email or "@" not in email:
        messages.error(request, "Please enter a valid email address.")
    else:
        _, created = NewsletterSubscriber.objects.get_or_create(email=email)
        text = "You’re on the list — welcome to the growth notes." if created else "You’re already subscribed to growth notes."
        messages.success(request, text)
    return redirect("home")


@require_GET
def terms(request):
    return render(request, "accounts/legal.html", {"title": "Terms of service"})


@require_GET
def privacy(request):
    return render(request, "accounts/legal.html", {"title": "Privacy policy"})


@require_POST
def api_register(request):
    data = _payload(request)
    if data is None:
        return JsonResponse({"detail": "Request body must be valid JSON."}, status=400)
    form = RegistrationForm(data)
    if not form.is_valid():
        return JsonResponse({"errors": form.errors.get_json_data()}, status=400)
    user = form.save()
    return JsonResponse({"message": "Account created. Please log in.", "user": {"id": user.id, "username": user.username}}, status=201)


@require_POST
def api_login(request):
    data = _payload(request)
    if data is None:
        return JsonResponse({"detail": "Request body must be valid JSON."}, status=400)
    username, password = data.get("username", ""), data.get("password", "")
    user = authenticate(request, username=username, password=password)
    if user is None:
        return JsonResponse({"detail": "Invalid username or password."}, status=401)
    login(request, user)
    return JsonResponse({"message": "Logged in.", "user": {"id": user.id, "username": user.username, "email": user.email}})


@require_POST
def api_logout(request):
    logout(request)
    return JsonResponse({"message": "Logged out."})


@require_GET
def api_me(request):
    if not request.user.is_authenticated:
        return JsonResponse({"detail": "Authentication required."}, status=401)
    return JsonResponse({"id": request.user.id, "username": request.user.username, "first_name": request.user.first_name, "email": request.user.email})
