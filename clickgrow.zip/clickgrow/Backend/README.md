# ClickGrown Django backend

## What is included

- Django authentication using the built-in secure `User` model and SQLite (`db.sqlite3` is created during migration).
- Branded registration, login, protected homepage, and logout flows.
- Form and API validation, password hashing, CSRF protection, Django password validators, and session authentication.
- JSON authentication endpoints for future frontend or mobile integrations.

## Run locally

Python is required. From this `Backend` folder:

```powershell
py -m pip install -r requirements.txt
py manage.py migrate
py manage.py runserver
```

Open `http://127.0.0.1:8000/register/`. Registration redirects to login, and successful login redirects to the protected homepage.

## API endpoints

All POST endpoints require a CSRF token when called from a browser session.

| Method | Endpoint | Purpose |
| --- | --- | --- |
| POST | `/api/auth/register/` | Register with `first_name`, `username`, `email`, `password1`, `password2` |
| POST | `/api/auth/login/` | Sign in with `username`, `password` |
| POST | `/api/auth/logout/` | End session |
| GET | `/api/auth/me/` | Return the authenticated user |

For production, set `DEBUG=False`, provide `SECRET_KEY` through an environment variable, configure `ALLOWED_HOSTS`, and use HTTPS.
